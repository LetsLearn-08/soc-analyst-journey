const express = require('express');
const authMiddleware = require('../middleware/auth');

const router = express.Router();

// GET /api/dashboard — protected route
router.get('/', authMiddleware, (req, res) => {
  const stats = {
    totalLogins: Math.floor(Math.random() * 100) + 1,
    accountAge: Math.floor((Date.now() - new Date(req.user.createdAt)) / (1000 * 60 * 60 * 24)),
    lastLogin: req.user.lastLogin || req.user.createdAt,
    securityScore: 85
  };

  res.json({
    message: `Welcome back, ${req.user.username}!`,
    user: req.user,
    stats
  });
});

module.exports = router;
