import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import './Dashboard.css';

const API_URL = process.env.REACT_APP_API_URL || '/api';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [dashData, setDashData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    axios.get(`${API_URL}/dashboard`)
      .then(res => setDashData(res.data))
      .catch(err => {
        if (err.response?.status === 401) navigate('/auth');
      })
      .finally(() => setLoading(false));

    const clock = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(clock);
  }, [navigate]);

  const handleLogout = async () => {
    await logout();
    navigate('/auth');
  };

  const formatDate = (d) => new Date(d).toLocaleDateString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric'
  });

  if (loading) return (
    <div className="loading-screen">
      <div className="loading-spinner"></div>
      <span>LOADING DASHBOARD...</span>
    </div>
  );

  const stats = dashData?.stats || {};

  return (
    <div className="dashboard-page">
      {/* Background grid + orbs */}
      <div className="dash-orb dash-orb-1"></div>
      <div className="dash-orb dash-orb-2"></div>

      {/* Topbar */}
      <header className="topbar">
        <div className="topbar-brand">
          <svg width="24" height="24" viewBox="0 0 36 36">
            <polygon points="18,2 34,10 34,26 18,34 2,26 2,10" fill="none" stroke="#00f5d4" strokeWidth="1.5"/>
            <circle cx="18" cy="18" r="4" fill="#00f5d4"/>
          </svg>
          <span className="topbar-title">NEXUS<span>AUTH</span></span>
        </div>

        <div className="topbar-clock">
          {time.toLocaleTimeString('en-US', { hour12: false })}
        </div>

        <div className="topbar-actions">
          <div className="user-badge">
            <div className="user-avatar">{user?.username?.[0]?.toUpperCase()}</div>
            <span className="user-name">{user?.username}</span>
          </div>
          <button className="logout-btn" onClick={handleLogout}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/>
            </svg>
            LOGOUT
          </button>
        </div>
      </header>

      {/* Main content */}
      <main className="dash-main">
        {/* Welcome banner */}
        <section className="welcome-section">
          <div className="welcome-text">
            <p className="welcome-sub">AUTHENTICATED SESSION ACTIVE</p>
            <h2 className="welcome-heading">Welcome back, <span>{user?.username}</span></h2>
          </div>
          <div className="status-badge">
            <span className="status-dot"></span>
            SECURE
          </div>
        </section>

        {/* Stats grid */}
        <section className="stats-grid">
          <StatCard
            label="SESSION STATUS"
            value="ACTIVE"
            sub="JWT Valid · 7 days"
            icon={<ShieldIcon />}
            highlight
          />
          <StatCard
            label="ACCOUNT AGE"
            value={`${stats.accountAge ?? 0}d`}
            sub={`Since ${formatDate(user?.createdAt)}`}
            icon={<CalendarIcon />}
          />
          <StatCard
            label="SECURITY SCORE"
            value={`${stats.securityScore ?? 0}%`}
            sub="Bcrypt + JWT"
            icon={<LockIcon />}
          />
          <StatCard
            label="LAST LOGIN"
            value={stats.lastLogin ? formatDate(stats.lastLogin) : 'Today'}
            sub={stats.lastLogin ? new Date(stats.lastLogin).toLocaleTimeString() : ''}
            icon={<ClockIcon />}
          />
        </section>

        {/* Info panels */}
        <section className="panels-grid">
          <div className="panel">
            <div className="panel-header">
              <h3>ACCOUNT DETAILS</h3>
              <div className="panel-line"></div>
            </div>
            <div className="detail-rows">
              <DetailRow label="USER ID" value={user?._id} mono />
              <DetailRow label="USERNAME" value={user?.username} />
              <DetailRow label="EMAIL" value={user?.email} />
              <DetailRow label="REGISTERED" value={formatDate(user?.createdAt)} />
              <DetailRow label="AUTH METHOD" value="JWT + Bcrypt" />
            </div>
          </div>

          <div className="panel">
            <div className="panel-header">
              <h3>SECURITY OVERVIEW</h3>
              <div className="panel-line"></div>
            </div>
            <div className="security-items">
              <SecurityItem label="Password Hashing" status="ACTIVE" detail="bcrypt · 12 rounds" />
              <SecurityItem label="Session Token" status="ACTIVE" detail="JWT RS256 · 7d expiry" />
              <SecurityItem label="CORS Protection" status="ACTIVE" detail="Origin-restricted" />
              <SecurityItem label="Input Validation" status="ACTIVE" detail="Mongoose schema" />
            </div>

            <div className="security-bar-wrap">
              <div className="security-bar-label">
                <span>SECURITY SCORE</span>
                <span className="score-val">{stats.securityScore ?? 0}%</span>
              </div>
              <div className="security-bar-track">
                <div className="security-bar-fill" style={{ width: `${stats.securityScore ?? 0}%` }}></div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function StatCard({ label, value, sub, icon, highlight }) {
  return (
    <div className={`stat-card ${highlight ? 'stat-highlight' : ''}`}>
      <div className="stat-icon">{icon}</div>
      <div className="stat-content">
        <p className="stat-label">{label}</p>
        <p className="stat-value">{value}</p>
        {sub && <p className="stat-sub">{sub}</p>}
      </div>
      <div className="stat-corner tl"></div>
      <div className="stat-corner br"></div>
    </div>
  );
}

function DetailRow({ label, value, mono }) {
  return (
    <div className="detail-row">
      <span className="detail-label">{label}</span>
      <span className={`detail-value ${mono ? 'mono' : ''}`}>{value}</span>
    </div>
  );
}

function SecurityItem({ label, status, detail }) {
  return (
    <div className="security-item">
      <div className="security-left">
        <span className="sec-dot"></span>
        <span className="sec-label">{label}</span>
      </div>
      <div className="security-right">
        <span className="sec-status">{status}</span>
        <span className="sec-detail">{detail}</span>
      </div>
    </div>
  );
}

// Icons
const ShieldIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    <polyline points="9 12 11 14 15 10"/>
  </svg>
);
const CalendarIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/>
    <line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
  </svg>
);
const LockIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/>
    <circle cx="12" cy="16" r="1" fill="currentColor"/>
  </svg>
);
const ClockIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
  </svg>
);
