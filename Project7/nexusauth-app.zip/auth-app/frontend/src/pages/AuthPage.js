import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './AuthPage.css';

export default function AuthPage() {
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [form, setForm] = useState({ username: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (mode === 'register') {
        await register(form.username, form.email, form.password);
      } else {
        await login(form.email, form.password);
      }
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const switchMode = (newMode) => {
    setMode(newMode);
    setError('');
    setForm({ username: '', email: '', password: '' });
  };

  return (
    <div className="auth-page">
      {/* Decorative geometric background */}
      <div className="geo-bg">
        <svg className="geo-svg" viewBox="0 0 1000 1000" preserveAspectRatio="xMidYMid slice">
          <polygon className="geo-shape s1" points="500,100 900,300 900,700 500,900 100,700 100,300"/>
          <polygon className="geo-shape s2" points="500,200 800,350 800,650 500,800 200,650 200,350"/>
          <polygon className="geo-shape s3" points="500,300 700,400 700,600 500,700 300,600 300,400"/>
          <line className="geo-line" x1="100" y1="300" x2="900" y2="300"/>
          <line className="geo-line" x1="100" y1="700" x2="900" y2="700"/>
          <line className="geo-line" x1="500" y1="100" x2="500" y2="900"/>
          <circle className="geo-circle" cx="500" cy="500" r="180"/>
          <circle className="geo-circle-sm" cx="200" cy="200" r="40"/>
          <circle className="geo-circle-sm" cx="800" cy="800" r="40"/>
          <circle className="geo-circle-sm" cx="800" cy="200" r="25"/>
          <circle className="geo-circle-sm" cx="200" cy="800" r="25"/>
        </svg>
      </div>

      {/* Ambient glow orbs */}
      <div className="orb orb-1"></div>
      <div className="orb orb-2"></div>

      {/* Auth Card */}
      <div className="auth-card" style={{ animation: 'cardIn 0.6s cubic-bezier(0.22, 1, 0.36, 1) both' }}>
        {/* Header */}
        <div className="auth-header">
          <div className="logo-mark">
            <svg width="36" height="36" viewBox="0 0 36 36">
              <polygon points="18,2 34,10 34,26 18,34 2,26 2,10" fill="none" stroke="#00f5d4" strokeWidth="1.5"/>
              <polygon points="18,8 28,13 28,23 18,28 8,23 8,13" fill="none" stroke="#00f5d4" strokeWidth="0.75" opacity="0.5"/>
              <circle cx="18" cy="18" r="4" fill="#00f5d4"/>
            </svg>
          </div>
          <h1 className="brand-name">NEXUS<span>AUTH</span></h1>
          <p className="brand-sub">SECURE ACCESS PROTOCOL</p>
        </div>

        {/* Mode Tabs */}
        <div className="mode-tabs">
          <button
            className={`tab-btn ${mode === 'login' ? 'active' : ''}`}
            onClick={() => switchMode('login')}
          >LOGIN</button>
          <button
            className={`tab-btn ${mode === 'register' ? 'active' : ''}`}
            onClick={() => switchMode('register')}
          >REGISTER</button>
          <div className={`tab-indicator ${mode === 'register' ? 'right' : ''}`}></div>
        </div>

        {/* Form */}
        <form className="auth-form" onSubmit={handleSubmit} noValidate>
          {mode === 'register' && (
            <div className="field-group" key="username">
              <label className="field-label">USERNAME</label>
              <input
                className="cyber-input"
                type="text"
                name="username"
                placeholder="ENTER USERNAME"
                value={form.username}
                onChange={handleChange}
                autoComplete="username"
                required
              />
            </div>
          )}

          <div className="field-group">
            <label className="field-label">EMAIL ADDRESS</label>
            <input
              className="cyber-input"
              type="email"
              name="email"
              placeholder="USER@DOMAIN.COM"
              value={form.email}
              onChange={handleChange}
              autoComplete="email"
              required
            />
          </div>

          <div className="field-group">
            <label className="field-label">PASSWORD</label>
            <input
              className="cyber-input"
              type="password"
              name="password"
              placeholder="••••••••••••"
              value={form.password}
              onChange={handleChange}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              required
            />
          </div>

          {error && (
            <div className="error-msg">
              <span className="error-icon">⚠</span>
              {error}
            </div>
          )}

          <button className="cyber-btn submit-btn" type="submit" disabled={loading}>
            {loading ? (
              <span className="btn-loading">
                <span className="dot"></span><span className="dot"></span><span className="dot"></span>
              </span>
            ) : (
              mode === 'login' ? 'AUTHENTICATE' : 'CREATE ACCOUNT'
            )}
          </button>
        </form>

        {/* Corner decorations */}
        <div className="corner tl"></div>
        <div className="corner tr"></div>
        <div className="corner bl"></div>
        <div className="corner br"></div>
      </div>

      {/* Footer */}
      <div className="auth-footer">
        <span className="footer-line"></span>
        <span>256-BIT ENCRYPTED</span>
        <span className="footer-sep">◆</span>
        <span>JWT SECURED</span>
        <span className="footer-sep">◆</span>
        <span>BCRYPT HASHED</span>
        <span className="footer-line"></span>
      </div>
    </div>
  );
}
